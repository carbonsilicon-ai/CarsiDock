_build_config = {
    "PYDOCK_VERSION" : "0.4",
    "PYDOCK_BUILD_TYPE" : ""
}
